import app from "./config/app";
import env from './environment'
import * as cors from 'cors';
const PORT = env.getPort();
app.options('*', cors());
app.listen(PORT, () => {
   console.log('Express server listening on port ' + PORT);
});