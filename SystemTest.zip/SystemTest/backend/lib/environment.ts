enum Environments {
    local_environment = 'local',
    dev_environment = 'dev',
    prod_environment = 'prod',
    qa_environment = 'qa'
}

class Environment {
    private environment: String;

    constructor(environment: String) {
        this.environment = environment;
    }

    getPort(): Number {
         if (this.environment === Environments.dev_environment) {
            return 8082;
        } else {
            return 3000;
        }
    }

    getDBName(): String {
        //  if (this.environment === Environments.dev_environment) {
        //     return 'db_test_project_dev';
        // } else {
        //     return 'db_test_project_local';
        // }
        return 'db_test_project_dev';
    }
}

export default new Environment(Environments.local_environment);
